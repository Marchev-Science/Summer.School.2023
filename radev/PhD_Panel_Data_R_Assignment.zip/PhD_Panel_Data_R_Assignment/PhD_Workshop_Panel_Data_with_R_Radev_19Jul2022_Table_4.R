# File:   PhD_Workshop_Panel_Data_with_R_Radev.r
# Course: PhD Workshop on Panel Data Methods with R
# Author: Deyan Radev, PhD, FEBA at Sofia University
# Date:   July 19, 2023
# GitHub Repository: 



# Clear environment
rm(list = ls()) 

# Clear plots
#dev.off()  # But only if there IS a plot

# Clear console
cat("\014")  # ctrl+L



############# PREPARING THE WORKING ENVIRONMENT ############

# install.packages("package name", dependencies = TRUE)

# Sys.setenv(https_proxy = "10.22.122.14:8080")

# Setting Working directory

getwd ( )
setwd ("D:/Dropbox/Sofia University/Teaching/PhD/PhD Workshops/2023/Assignment/Data")
getwd ( )



# INSTALL AND LOAD PACKAGES ################################

# library(datasets)  # Load base packages manually


# 1. Loading data and packages 


library(foreign)

ds_Fintech = read.dta("./fintech_radev_penev_19Jul2023.dta") # Load Stata v12 file






# 2. Visualization: Figures o Number of companies per year


library(dplyr)
my_summary_data <- ds_Fintech %>%
  group_by(year) %>%
  summarise(Count = n())     


plot(my_summary_data$year, my_summary_data$Count, type="l", col="blue", lwd=5, xlab="time", ylab="Total Fintech Companies", main="Fintech Companies")


Count_diff= diff(my_summary_data$Count, differences=1)

Count_diff=Count_diff[1:14]

year_diff=my_summary_data$year[2:15]

plot(year_diff, Count_diff, type="l", col="blue", lwd=5, xlab="time", ylab="New Fintech Companies", main="New Fintech Companies")






# 3. Generate variables



# Dependent variables

ds_Fintech$size_profit =log(ds_Fintech$profit_loss)


ds_Fintech$size_personnel_costs =log(ds_Fintech$personnel_costs)


ds_Fintech$size_personnel_nr =log(ds_Fintech$personnel_nr)


# independent variables

ds_Fintech$size = log(ds_Fintech$total_assets)

ds_Fintech$capitalization = ds_Fintech$common_shares/ds_Fintech$total_assets*100


# winsorizing data

summary(ds_Fintech$capitalization)

# install.packages("DescTools", dependencies=TRUE)

library(DescTools)

ds_Fintech$capitalization_win = Winsorize(ds_Fintech$capitalization, na.rm=TRUE, probs = c(0.25, 0.75))
ds_Fintech$cap_win = Winsorize(ds_Fintech$capitalization, na.rm=TRUE, probs = c(0.25, 0.75))

ds_Fintech$st_tangibles = log(ds_Fintech$st_tangible_assets)

ds_Fintech$fin_assets = log(ds_Fintech$financial_assets)

ds_Fintech$lending = log(ds_Fintech$st_lending)

ds_Fintech$ext_services_expenses = log(ds_Fintech$external_services_expenses)
ds_Fintech$ext_serv = log(ds_Fintech$external_services_expenses)

ds_Fintech$oper_income = log(ds_Fintech$operating_income)



# 4. Fixed effects estimation

# ds_Fintech

#install.packages("stargazer", dependencies=TRUE)
library(stargazer)


# install.packages("plm", dependencies=TRUE)

library(plm)

data_Fintech_limited <- subset(ds_Fintech,  oper_income!="." &  size_personnel_costs!="." & size_personnel_nr!=".")


# 4.1. Table 4: Baseline regressions




# Column 0

p1 <- lm(oper_income ~  size + cap_win + st_tangibles + fin_assets + lending + external_services_expenses, data=data_Fintech_limited)


summary(p1)



# Column 1

f1 <- plm(oper_income ~  size + cap_win + st_tangibles + fin_assets + lending + ext_serv, data=data_Fintech_limited, index=c("company_name_eik_num", "year"), model="within")


summary(f1)


# Column 2

f2 <- plm(oper_income ~  size + cap_win + st_tangibles + fin_assets + lending + ext_serv + gdp_growth + inflation + unemp_tot, data=data_Fintech_limited, index=c("company_name_eik_num", "year"), model="within")


summary(f2)


# Column 3

f3 <- plm(size_personnel_costs ~  size + cap_win + st_tangibles + fin_assets + lending + ext_serv, data=data_Fintech_limited, index=c("company_name_eik_num", "year"), model="within")


summary(f3)


# Column 4

f4 <- plm(size_personnel_costs ~  size + cap_win + st_tangibles + fin_assets + lending + ext_serv + gdp_growth + inflation + unemp_tot, data=data_Fintech_limited, index=c("company_name_eik_num", "year"), model="within")


summary(f4)


# Column 5

f5 <- plm(size_personnel_nr ~  size + cap_win + st_tangibles + fin_assets + lending + ext_serv, data=data_Fintech_limited, index=c("company_name_eik_num", "year"), model="within")


summary(f5)


# Column 6

f6 <- plm(size_personnel_nr ~  size + cap_win + st_tangibles + fin_assets + lending + ext_serv + gdp_growth + inflation + unemp_tot, data=data_Fintech_limited, index=c("company_name_eik_num", "year"), model="within")


summary(f6)

# Column 7

f7 <- plm(size_profit ~  size + cap_win + st_tangibles + fin_assets + lending + ext_serv + gdp_growth + inflation + unemp_tot, data=data_Fintech_limited, index=c("company_name_eik_num", "year"), model="within")


summary(f7)



data_Fintech_lim_Profit <- subset(data_Fintech_limited,  size_profit!="." & size_profit!="NaN")



# Column 8

f8 <- plm(oper_income ~  size + cap_win + st_tangibles + fin_assets + lending + ext_serv + gdp_growth + inflation + unemp_tot, data=data_Fintech_lim_Profit, index=c("company_name_eik_num", "year"), model="within")


summary(f8)



# Regression outputs in a table format (needs short model names - e.g., f1, instead of fixed1)

stargazer(f1, f2, f3, f4, f5, f6, f7, f8, keep = c(1,2,3), flip = TRUE, type = 'html', keep.stat = 'n')

stargazer(f1, f2, f3, f4, f5, f6, f7, f8, keep = c(1,2,3), flip = TRUE, type = 'latex', keep.stat = 'n')


# Test with different definitions of robust standard errors

#install.packages("lmtest", dependencies=TRUE)
#install.packages("sandwich", dependencies=TRUE)

library("lmtest")
library("sandwich")


coeftest(fixed8, vcov = vcovHC(fixed8, type = "HC0"))
coeftest(fixed8, vcov = vcovHC(fixed8, type = "HC1"))
coeftest(fixed8, vcov = vcovHC(fixed8, type = "HC2"))
coeftest(fixed8, vcov = vcovHC(fixed8, type = "HC3"))
coeftest(fixed8, vcov = vcovHC(fixed8, type = "HC4"))
coeftest(fixed8, vcov = vcovHC(fixed8, type = "sss"))

coeftest(fixed8, vcov = vcovHC(fixed8, method = "white1"))
coeftest(fixed8, vcov = vcovHC(fixed8, method = "white2"))


coeftest(fixed8, vcov = vcovHC(fixed8, method = "white1", type = "HC0"))
coeftest(fixed8, vcov = vcovHC(fixed8, method = "white1", type = "HC4"))

coeftest(fixed8, vcov = vcovHC(fixed8, method = "arellano", type = "HC0"))
coeftest(fixed8, vcov = vcovHC(fixed8, method = "arellano", type = "HC4"))





# 4.2. Table 5: Brexit Regressions






# CLEAN UP #################################################

# Clear environment
rm(list = ls()) 

# Clear packages
p_unload(all)  # Remove all add-ons
detach("package:datasets", unload = TRUE)  # For base

# Clear plots
dev.off()  # But only if there IS a plot

# Clear console
cat("\014")  # ctrl+L

# Clear mind :)
